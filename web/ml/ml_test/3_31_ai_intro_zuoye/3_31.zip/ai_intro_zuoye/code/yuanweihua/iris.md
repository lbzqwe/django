## Test
### Test3
iris以鸢尾花的特征作为数据来源，常用在分类操作中。该数据集由3种不同类型的鸢尾花的50个样本数据构成。其中的一个种类与另外两个种类是线性可分离的，后两个种类是非线性可分离的。
该数据集包含了5个属性：
& Sepal.Length（花萼长度），单位是cm;
& Sepal.Width（花萼宽度），单位是cm;
& Petal.Length（花瓣长度），单位是cm;
& Petal.Width（花瓣宽度），单位是cm;
& 种类：Iris Setosa（山鸢尾）、Iris Versicolour（杂色鸢尾），以及Iris Virginica（维吉尼亚鸢尾）。
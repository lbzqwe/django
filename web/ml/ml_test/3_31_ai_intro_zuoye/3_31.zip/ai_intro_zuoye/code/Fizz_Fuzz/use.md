#use method

libaozhi@ubuntu:~/Desktop/3_31_ai_intro_zuoye/ai_intro_zuoye/code/Fizz_Fuzz$ python3.5  fz_lr_clean.py  9887
test true result
[0 0 1 0 2]
test predict result
[0 0 1 0 2]
Mean squared error : 0.00
input number 9887
predict value 9887
1.0

